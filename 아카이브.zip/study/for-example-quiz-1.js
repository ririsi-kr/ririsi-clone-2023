function main() {
  const fruits = ["사과", "귤", "수박", "메론", "포도", "체리"];

  console.log("과일 길이는?:");
}

main();

// 과일 길이를 출력하는 방법은?(array 관련 내용 복습)
