function main(num) {
  for (let i = 0; i < num; i = i + 1) {
    console.log(i);
  }
}

main(10);
