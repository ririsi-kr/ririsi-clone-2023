function main(num) {
  for (let i = 0; i < num; i = i + 1) {
    console.log(i * 3);
  }
}

main(10);
