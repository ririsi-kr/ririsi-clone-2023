function main() {
  const name = "Lee Kuy Ri";
  const divName = name.split(" ");

  console.log(divName[0]);

  // const arr = Array.from(name);
  // console.log(arr);

  //console.log(name.length);
  //console.log(name[9]);
  // for (let i = 0; i < 10; i = i + 1) {
  //   console.log(name[i]);
  // }
}

main();

// for (let i = 0; i < 6; i++) {
//   console.log(fruits[i]);
// }

// string 복습
// 0. name 의 길이를 출력하세요. // 10
// 1. name 의 10번째 글자를 출력하세요. // 'i'
// 2. name 을 한글자 한글자 출력하세요 ex) 'L', 'e', 'e', ' ', 'K' ... 이런식으로
